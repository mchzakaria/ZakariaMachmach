# Zakaria MACHMACH — Portfolio

  A creative developer portfolio built with React + Vite + TypeScript + Tailwind CSS.

  ## Features
  - Terminal-style loading screen & hero section
  - Interactive particle network background
  - VS Code-styled About section
  - GitHub contribution graph for Skills
  - Command palette (Ctrl+K)
  - Custom glowing cursor
  - Glitch effects on hover
  - Konami code easter egg (↑↑↓↓←→←→BA)
  - Console easter egg for curious devs
  - Scroll progress bar

  ## Getting Started

  ```bash
  npm install
  npm run dev
  ```

  ## Build for production

  ```bash
  npm run build
  npm run preview
  ```

  ## Deploy

  Push to GitHub, then connect to [Vercel](https://vercel.com) or [Netlify](https://netlify.com) — they auto-detect Vite.

  ## Stack
  - React 19 + TypeScript
  - Vite 7
  - Tailwind CSS v4
  - Framer Motion
  - Lucide React + React Icons
  - Wouter (routing)
  